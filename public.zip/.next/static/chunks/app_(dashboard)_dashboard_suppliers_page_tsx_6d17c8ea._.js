(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_cce7e5de._.js",
  "static/chunks/_8a48c18b._.js"
],
    source: "dynamic"
});
