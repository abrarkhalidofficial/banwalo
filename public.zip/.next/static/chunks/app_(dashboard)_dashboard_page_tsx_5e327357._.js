(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_4403b9b3._.js",
  "static/chunks/node_modules_f445efab._.js"
],
    source: "dynamic"
});
