(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_eeb4d40c._.js",
  "static/chunks/_b30d26da._.js"
],
    source: "dynamic"
});
