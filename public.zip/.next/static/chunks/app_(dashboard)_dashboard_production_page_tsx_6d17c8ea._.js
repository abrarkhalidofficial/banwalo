(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f17b4a6c._.js",
  "static/chunks/node_modules_0c4eb238._.js"
],
    source: "dynamic"
});
