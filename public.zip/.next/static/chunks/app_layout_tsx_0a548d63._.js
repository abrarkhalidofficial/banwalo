(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__b6f9dd27._.css",
  "static/chunks/node_modules_d55ba87e._.js",
  "static/chunks/providers_9e8df4ac._.js"
],
    source: "dynamic"
});
