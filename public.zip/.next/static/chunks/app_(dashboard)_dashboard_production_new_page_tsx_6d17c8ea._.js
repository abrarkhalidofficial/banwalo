(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f7c32c0c._.js",
  "static/chunks/node_modules_0773e35a._.js"
],
    source: "dynamic"
});
