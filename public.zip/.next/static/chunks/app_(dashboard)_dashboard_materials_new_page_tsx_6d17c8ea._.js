(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_47f34e00._.js",
  "static/chunks/_1cd7a625._.js"
],
    source: "dynamic"
});
